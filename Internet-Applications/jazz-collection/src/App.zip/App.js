import React, { useState } from 'react';
import ItemList from './ItemList';
import AddItemForm from './AddItemForm';
import initialData from './data.json';

function App() {
  const [items, setItems] = useState(initialData);
  const [showForm, setShowForm] = useState(false);

  const handleUpdateItem = (updatedItem) => {
    setItems(items.map(item => item.id === updatedItem.id ? updatedItem : item));
  };

  const handleAddItem = (newItem) => {
    setItems([...items, { ...newItem, id: items.length + 1 }]);
    setShowForm(false); // Hide form after adding an item
  };

  const handleDeleteItem = (itemId) => {
    setItems(items.filter(item => item.id !== itemId));
  };

  const toggleForm = () => {
    setShowForm(!showForm);
  };

  return (
    <div className="App">
      <header className="app-header">
        <h1>My Jazz Album Collection</h1>
        <button onClick={toggleForm} className="toggle-form-button">
          {showForm ? 'Hide Form' : 'Add New Album'}
        </button>
      </header>
      {showForm && <AddItemForm onAddItem={handleAddItem} />}
      <ItemList items={items} onUpdateItem={handleUpdateItem} onDeleteItem={handleDeleteItem} />
    </div>
  );
}

export default App;